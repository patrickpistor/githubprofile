These fonts are copyrighted 2009-2014 by Andreas Seidel aka astype.

These fonts may not be modified in any way unless it contains an unmodified 
copy of this text file and attributes Andreas Seidel aka astype in the font metadata.

astype is not liable for any damage resulting from the use of these fonts.

These fonts are free for personal use.

LICENSE: 
This work is licensed under the Attribution-NonCommercial-ShareAlike 4.0
International License. To view a copy of this license, visit 
http://creativecommons.org/licenses/by-nc-sa/4.0/ or send a letter to 
Creative Commons, PO Box 1866, CA 94042, USA.

Contact: 
www.astype.de
info@astype.de


